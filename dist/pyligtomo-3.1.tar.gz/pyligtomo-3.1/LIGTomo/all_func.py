from scipy.spatial import KDTree,Voronoi,ConvexHull, Delaunay
import numpy as np
import scipy.sparse as scsp
import traceback

"""This is class for velocity grid:
Here, you can create a velocity grid object and use the ray tracing method 
to determine the length of the ray path within each grid. 
For calculating the ray path length using tomography inversion, 
you can input irregular nodes. However, for ray tracing, 
you must input rectangular and regular grid nodes.
"""
class VelocityGrid:
    """
    input velocity grid node (x, y, z)
    xnode=1D array of regular grid x
    ynode=1D array of regular grid y
    znode=1D array of regular grid z
    gridV=3D array of regular grid velocity, you can do the interpolation first to have grid V from
    irreguler xyz velocity data into reguler xnode,ynode,znode grid.

    deltn=space between regular node
    delt=maximum distance in each seismic ray
    iter1 & iter2 = iteration number for psudo-bending
    tmin = error minimum for psudo-bending
    """
    def __init__(self,node,xnode,ynode,znode,gridV,deltn,delt,xfac,iter1,iter2,tmin,if_art):
        self.node=node
        self.xnode=xnode
        self.ynode=ynode
        self.znode=znode
        self.gridV=gridV
        self.deltn=deltn
        self.delt=delt
        self.xmin=np.amin(xnode)
        self.ymin=np.amin(ynode)
        self.zmin=np.amin(znode)
        self.xfac=xfac
        self.iter1=iter1
        self.iter2=iter2
        self.tmin=tmin
        self.if_art=if_art

    def vel(self,x, y, z):
        ix = int((x - self.xmin) / self.deltn)
        iy = int((y - self.ymin) / self.deltn)
        iz = int((z - self.zmin) / self.deltn)
        ix1 = ix + 1
        iy1 = iy + 1
        iz1 = iz + 1

        xf = (x - self.xnode[ix]) / (self.xnode[ix1] - self.xnode[ix])
        yf = (y - self.ynode[iy]) / (self.ynode[iy1] - self.ynode[iy])
        zf = (z - self.znode[iz]) / (self.znode[iz1] - self.znode[iz])
        xf1 = 1 - xf
        yf1 = 1 - yf
        zf1 = 1 - zf

        w1 = xf1 * yf1 * zf1
        w2 = xf * yf1 * zf1
        w3 = xf1 * yf * zf1
        w4 = xf * yf * zf1
        w5 = xf1 * yf1 * zf
        w6 = xf * yf1 * zf
        w7 = xf1 * yf * zf
        w8 = xf * yf * zf
        v = (w1 * self.gridV[ix, iy, iz]) + (w2 * self.gridV[ix1, iy, iz]) + (w3 * self.gridV[ix, iy1, iz]) + (
                w4 * self.gridV[ix1, iy1, iz]) + (w5 * self.gridV[ix, iy, iz1]) \
            + (w6 * self.gridV[ix1, iy, iz1]) + (w7 * self.gridV[ix, iy1, iz1]) + (w8 * self.gridV[ix1, iy1, iz1])
        return v

    def vel_vectorize(self,x,y,z):
        ix = ((x - self.xmin) / self.deltn).astype(int)
        iy = ((y - self.ymin) / self.deltn).astype(int)
        iz = ((z - self.zmin) / self.deltn).astype(int)
        ix1 = ix + 1
        iy1 = iy + 1
        iz1 = iz + 1

        xf = (x - self.xnode[ix]) / (self.xnode[ix1] - self.xnode[ix])
        yf = (y - self.ynode[iy]) / (self.ynode[iy1] - self.ynode[iy])
        zf = (z - self.znode[iz]) / (self.znode[iz1] - self.znode[iz])
        xf1 = 1 - xf
        yf1 = 1 - yf
        zf1 = 1 - zf

        w1 = xf1 * yf1 * zf1
        w2 = xf * yf1 * zf1
        w3 = xf1 * yf * zf1
        w4 = xf * yf * zf1
        w5 = xf1 * yf1 * zf
        w6 = xf * yf1 * zf
        w7 = xf1 * yf * zf
        w8 = xf * yf * zf
        v = (w1 * self.gridV[ix, iy, iz]) + (w2 * self.gridV[ix1, iy, iz]) + (w3 * self.gridV[ix, iy1, iz]) + (
                w4 * self.gridV[ix1, iy1, iz]) + (w5 * self.gridV[ix, iy, iz1]) \
            + (w6 * self.gridV[ix1, iy, iz1]) + (w7 * self.gridV[ix, iy1, iz1]) + (w8 * self.gridV[ix1, iy1, iz1])
        return v

    def veld(self,x, y, z):
        ix = int((x - self.xmin) / self.deltn)
        iy = int((y - self.ymin) / self.deltn)
        iz = int((z - self.zmin) / self.deltn)
        ix1 = ix + 1
        iy1 = iy + 1
        iz1 = iz + 1

        xf = (x - self.xnode[ix]) / (self.xnode[ix1] - self.xnode[ix])
        yf = (y - self.ynode[iy]) / (self.ynode[iy1] - self.ynode[iy])
        zf = (z - self.znode[iz]) / (self.znode[iz1] - self.znode[iz])
        xf1 = 1 - xf
        yf1 = 1 - yf
        zf1 = 1 - zf

        dvx = ((yf1 * zf1 * (self.gridV[ix1, iy, iz] - self.gridV[ix, iy, iz])) + (
                yf * zf1 * (self.gridV[ix1, iy1, iz] - self.gridV[ix, iy1, iz])) + (
                       yf1 * zf * (self.gridV[ix1, iy, iz1] - self.gridV[ix, iy, iz1])) + (
                       yf * zf * (self.gridV[ix1, iy1, iz1] - self.gridV[ix, iy1, iz1]))) / (self.xnode[ix1] - self.xnode[ix])

        dvy = ((xf1 * zf1 * (self.gridV[ix, iy1, iz] - self.gridV[ix, iy, iz])) + (
                xf * zf1 * (self.gridV[ix1, iy1, iz] - self.gridV[ix1, iy, iz])) + (
                       xf1 * zf * (self.gridV[ix, iy1, iz1] - self.gridV[ix, iy, iz1])) + (
                       xf * zf * (self.gridV[ix1, iy1, iz1] - self.gridV[ix1, iy, iz1]))) / (self.ynode[iy1] - self.ynode[iy])

        dvz = ((xf1 * yf1 * (self.gridV[ix, iy, iz1] - self.gridV[ix, iy, iz])) + (
                xf * yf1 * (self.gridV[ix1, iy, iz1] - self.gridV[ix1, iy, iz])) + (
                       xf1 * yf * (self.gridV[ix, iy1, iz1] - self.gridV[ix, iy1, iz])) + (
                       xf * yf * (self.gridV[ix1, iy1, iz1] - self.gridV[ix1, iy1, iz]))) / (self.znode[iz1] - self.znode[iz])
        return dvx, dvy, dvz

    def tt(self,path):
        path_mirror=path[1:]
        distance_path=np.linalg.norm(path[:-1]-path_mirror,axis=1)
        if (distance_path > 2*self.delt).any():
            spaces = np.where(distance_path <= 2 * self.delt, 1, np.round(distance_path / self.delt).astype(int))
            max_space = spaces.max()
            steps = np.arange(1, max_space + 1)[:, None]
            mask = steps <= spaces
            t_step = steps/spaces
            all_points = path[:-1][None, :, :] + t_step[:, :, None] * (path_mirror - path[:-1])[None, :, :]
            valid_points = all_points.transpose(1, 0, 2)[mask.T]
            path = np.vstack([path[0:1], valid_points])

        #vectorize tt calculation
        path_mirror=path[1:]
        distance_path=np.linalg.norm(path[:-1]-path_mirror,axis=1)
        velo=self.vel_vectorize(path[:, 0], path[:, 1], path[:, 2])
        slow=1/velo
        s1 = slow[:-1]
        s2 = slow[1:]
        tt = np.sum(distance_path/2*(s1+s2))
        return tt

    def rodrigues_rotation(self, n, axis, angle):
        #Rotate vector v around axis by angle using Rodrigues' formula.
        axis = axis / np.linalg.norm(axis)
        return (n * np.cos(angle)+ np.cross(axis, n) * np.sin(angle)+ axis * np.dot(axis, n)
                * (1.0 - np.cos(angle)))

    def get_plane_normal(self,ray_direction,plane_angle):
        #Generate a normal vector defining the plane of the circular arc.
        #plane_angle controls the rotation of the arc plane around the Source-Receiver direction.
        u = ray_direction / np.linalg.norm(ray_direction)
        # Reference vector
        ref = np.array([0.0, 0.0, 1.0])
        # Avoid parallel vectors
        if abs(np.dot(u, ref)) > 0.9:
            ref = np.array([0.0, 1.0, 0.0])
        # Make ref perpendicular to ray direction
        q = ref - np.dot(ref, u) * u
        q /= np.linalg.norm(q)
        # Another perpendicular vector
        p = np.cross(u, q)
        p /= np.linalg.norm(p)
        # Rotate the plane orientation
        n = np.cos(plane_angle) * q + np.sin(plane_angle) * p
        n /= np.linalg.norm(n)
        return n

    def generate_circular_arc(self,source,receiver,radius,plane_angle,npoints,side):
        d = receiver - source
        L = np.linalg.norm(d)
        if L == 0:
            raise ValueError("Source and receiver cannot be identical.")
        if radius < L / 2:
            raise ValueError(f"Radius must be >= {L / 2:.3f}")

        u = d / L
        M = 0.5 * (source + receiver)
        n = self.get_plane_normal(u, plane_angle)
        h = np.sqrt(radius ** 2 - (L / 2) ** 2)
        C = M + side * h * n
        k = np.cross(u, n)
        k /= np.linalg.norm(k)
        e0 = (source - C) / radius
        e1 = (receiver - C) / radius
        theta = np.arctan2(np.dot(k, np.cross(e0, e1)),np.dot(e0, e1))
        t = np.linspace(0.0, 1.0, npoints)
        points = []
        for ti in t:
            angle = theta * ti
            e = self.rodrigues_rotation(e0,k,angle)
            point = C + radius * e
            points.append(point)
        return np.asarray(points)

    def approximate_ray_tracing(self,path,npoints):
        #Approximate Ray Tracing (ART).Generates multiple circular arcs and selects the arc with minimum travel time.
        best_path=path
        min_ttime=self.tt(path)
        L=np.linalg.norm(path[0]-path[-1])
        radius_list = [
            0.51 * L,
            0.6 * L,
            0.8 * L,
            1.0 * L,
            1.5 * L,
            2.0 * L,
            5.0 * L,
            10.0 * L,
            100.0 * L
        ]
        plane_angles = np.linspace(0,np.pi,12,endpoint=False
)
        for angle in plane_angles:
            for radius in radius_list:
                # Two possible bending directions
                for side in [-1, 1]:
                    try:
                        pathn = self.generate_circular_arc(path[0,:],path[-1,:],radius,angle,npoints,side)
                        tt   = self.tt(pathn)
                    except ValueError:
                        continue

                    if tt<min_ttime:
                        best_path = pathn
        if best_path is None:
            raise ValueError("No path found.")
        return best_path


    def pertub(self,a, b, c):
        mid = ((b - a) / 2) + a
        gVx, gVy, gVz = self.veld(mid[0], mid[1], mid[2])
        gV = np.array([gVx, gVy, gVz])
        # n direction
        n = gV - (np.dot(gV, (b - a)) * (b - a) / (np.dot(b - a, b - a)))
        if not np.any(n) == False:
            n = n / np.sqrt(np.dot(n, n))
            Vmid = self.vel(mid[0], mid[1], mid[2])
            Sa = 1 / self.vel(a[0],a[1],a[2])
            Sb = 1 / self.vel(b[0],b[1],b[2])
            # R determination
            kL=np.sqrt(np.dot(b-mid,b-mid))
            kC=(Sa+Sb)/2

            R=(-(kC*Vmid+1)/(np.dot(4*kC*n,gV)))+np.sqrt((((kC*Vmid)+1)**2/((np.dot(4*kC*n,gV))**2))+(kL**2/2/kC/Vmid))
#            rcur = Vmid / sqrt(np.dot(n, n))
#            if rcur ** 2 > 0.25 * (np.dot(b - a, b - a)):
#                R = rcur - sqrt(rcur ** 2 - 0.25 * (np.dot(b - a, b - a)))
#            else:
#               R = rcur
            if np.isfinite(R):
                new = mid + (n * R)
                c = (self.xfac * (new - c)) + c
        return c

    def doublepath(self,path):
        diffs=path[1:]-path[:-1]
        dis=np.linalg.norm(diffs,axis=1)
        if np.any(dis < 2*self.delt):
            return np.copy(path)
        midpoints = path[:-1]+(diffs/2)
        pathnew=np.empty((path.shape[0]+midpoints.shape[0],path.shape[1]),dtype=path.dtype)
        pathnew[0::2]=path
        pathnew[1::2]=midpoints
        return pathnew

    def pertubray(self,path):
        it = int((path.shape[0] - 1) / 2)
        le = (path.shape[0] - 1)
        pathn = np.copy(path)
        for i in range(1, it + 1):
            pathn[i, :] = self.pertub(pathn[i - 1], pathn[i + 1], pathn[i])
            if i != it:
                pathn[le - i, :] = self.pertub(pathn[le - i - 1], pathn[le - i + 1], pathn[le - i])
        return pathn

    """method for psudobending with ART initialization"""
    def psudobending(self,path):
        if self.if_art==True:
            diss = path[0] - path[-1]
            npoints = max(3, int(np.ceil(np.linalg.norm(diss) / (2 * self.delt))) + 1)
            path = self.approximate_ray_tracing(path,npoints)
        pathn = self.doublepath(path)
        tt0 = self.tt(pathn)
        for i in range(0, self.iter1):
            for j in range(0, self.iter2):
                #print(i,j)
                pathn1 = self.pertubray(pathn)
                tt1 = self.tt(pathn1)
                if abs(tt0 - tt1) <= self.tmin:
                    break
                tt0 = np.copy(tt1)
                pathn = np.copy(pathn1)
            pathn = self.doublepath(pathn)
            pathn1 = self.pertubray(pathn)
            tt1 = self.tt(pathn1)
            if abs(tt0 - tt1) <= self.tmin:
                break
            tt0 = np.copy(tt1)
            pathn = np.copy(pathn1)
        return pathn, tt0

    """method to count raypath length in each irregular node"""
    """vectorize mode for faster without loop"""
    def crkernel(self, path):
        path_mirror=path[1:]
        distance_path=np.linalg.norm(path[:-1]-path_mirror,axis=1)
        if (distance_path > 2*self.delt).any():
            #vectorize for adding node
            spaces = np.where(distance_path <= 2 * self.delt, 1, np.round(distance_path / self.delt).astype(int))
            max_space = spaces.max()
            steps = np.arange(1, max_space + 1)[:, None]
            mask = steps <= spaces
            t_step = steps/spaces
            all_points = path[:-1][None, :, :] + t_step[:, :, None] * (path_mirror - path[:-1])[None, :, :]
            valid_points = all_points.transpose(1, 0, 2)[mask.T]
            path = np.vstack([path[0:1], valid_points])

        path_mirror=path[1:]
        distance_path=np.linalg.norm(path_mirror-path[:-1],axis=1)
        half_distance=distance_path/2
        mytree = KDTree(self.node)
        ind=mytree.query(path)[1]
        krn = np.zeros(len(self.node))
        #Add half the distance to the starting nodes (ind[i])
        np.add.at(krn, ind[:-1], half_distance)
        #Add half the distance to the ending nodes (ind[i+1])
        np.add.at(krn, ind[1:], half_distance)
        return scsp.csr_array(krn.reshape(1,-1))

    """method to count raypath length in each irregular node
    with added the direction for the raypath for irregular nodes adaptation"""
    """vectorize mode for faster without loop"""
    def crkernel_tensor(self, path):
        path_mirror=path[1:]
        distance_path=np.linalg.norm(path[:-1]-path_mirror,axis=1)
        if (distance_path > 2*self.delt).any():
            #vectorize for adding node
            spaces = np.where(distance_path <= 2 * self.delt, 1, np.round(distance_path / self.delt).astype(int))
            max_space = spaces.max()
            steps = np.arange(1, max_space + 1)[:, None]
            mask = steps <= spaces
            t_step = steps/spaces
            all_points = path[:-1][None, :, :] + t_step[:, :, None] * (path_mirror - path[:-1])[None, :, :]
            valid_points = all_points.transpose(1, 0, 2)[mask.T]
            path = np.vstack([path[0:1], valid_points])

        path_mirror=path[1:]
        delta=path_mirror-path[:-1]
        distance_path=np.linalg.norm(delta,axis=1)
        u=delta/distance_path[:,None]
        ux=u[:,0]
        uy=u[:,1]
        uz=u[:,2]
        half_distance=distance_path/2
        mytree = KDTree(self.node)
        ind=mytree.query(path)[1]
        krn = np.zeros(len(self.node))
        ax_sum = np.zeros(len(self.node))
        ay_sum = np.zeros(len(self.node))
        az_sum = np.zeros(len(self.node))

        #Add half the distance to the starting nodes (ind[i])
        np.add.at(krn, ind[:-1], half_distance)
        np.add.at(ax_sum, ind[:-1], half_distance * ux)
        np.add.at(ay_sum, ind[:-1], half_distance * uy)
        np.add.at(az_sum, ind[:-1], half_distance * uz)
        #Add half the distance to the ending nodes (ind[i+1])
        np.add.at(krn, ind[1:], half_distance)
        np.add.at(ax_sum, ind[1:], half_distance * ux)
        np.add.at(ay_sum, ind[1:], half_distance * uy)
        np.add.at(az_sum, ind[1:], half_distance * uz)
        return scsp.csr_array(krn.reshape(1,-1)),scsp.csr_array(ax_sum.reshape(1,-1)),scsp.csr_array(ay_sum.reshape(1,-1)),scsp.csr_array(az_sum.reshape(1, -1))

    """method for create hypocenter derivative"""
    def hypo_deriv(self, path):
        s = 1 / self.vel(path[0][0], path[0][1], path[0][2])
        delta_s = path[1]-path[0]
        delta_s_abs = np.sqrt(np.dot(delta_s,delta_s))
        hypo_der=-s*delta_s/delta_s_abs
        hypo_der=np.insert(hypo_der,0,1)
        return hypo_der

    """method to call all the three method for each data"""
    def forwardtwopoints(self, path):
        pathn, tt = self.psudobending(path)
        gkernl = self.crkernel(pathn)
        hypo_der= self.hypo_deriv(pathn)
        return pathn, tt, gkernl, hypo_der

    """method to call all the three method for each data for tensor calculation"""
    def forwardtwopoints_tensor(self, path):
        pathn, tt = self.psudobending(path)
        gkernl,ax,ay,az = self.crkernel_tensor(pathn)
        hypo_der= self.hypo_deriv(pathn)
        return pathn, tt, gkernl, hypo_der, ax,ay,az

    def ttime_only(self, path):
        pathn, tt = self.psudobending(path)
        return pathn, tt

    """method to change node if there is a change"""
    def change_node(self, newnode):
        self.node=newnode

    """handling error for forward modeling when using multiprocessing"""
    def safe_crkernel(self,path):
        try:
            return self.crkernel(path)
        except Exception as e:
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
    def safe_crkernel_tensor(self,path):
        try:
            return self.crkernel_tensor(path)
        except Exception as e:
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
    def safe_forwardtwopoints(self,path):
        try:
            return self.forwardtwopoints(path)
        except Exception as e:
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
    def safe_forwardtwopoints_tensor(self,path):
        try:
            return self.forwardtwopoints_tensor(path)
        except Exception as e:
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
    def safe_ttime_only(self,path):
        try:
            return self.ttime_only(path)
        except Exception as e:
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }

"""function to count the volume for each voronoi diagram for a given xyz irregular node"""
def vor_volumes(points):
    v = Voronoi(points)
    vol = np.zeros(v.npoints)
    for i, reg_num in enumerate(v.point_region):
        indices = v.regions[reg_num]
        if -1 in indices: # some regions can be opened
            vol[i] = 0
        else:
            vol[i] = ConvexHull(v.vertices[indices]).volume
    return vol

def count_tensor_dens(Ax,Ay,Az):
    inv_length = (Ax.multiply(Ax)+ Ay.multiply(Ay)+ Az.multiply(Az)).tocsr()
    inv_length.data = np.sqrt(inv_length.data)
    inv_length.eliminate_zeros()
    inv_length.data = 1.0 / inv_length.data

    def colsum(matrix):
        return np.asarray(matrix.sum(axis=0)).ravel()
    Rxx = colsum(Ax.multiply(Ax).multiply(inv_length))
    Ryy = colsum(Ay.multiply(Ay).multiply(inv_length))
    Rzz = colsum(Az.multiply(Az).multiply(inv_length))

    Rxy = colsum(Ax.multiply(Ay).multiply(inv_length))
    Rxz = colsum(Ax.multiply(Az).multiply(inv_length))
    Ryz = colsum(Ay.multiply(Az).multiply(inv_length))

    RDT = np.zeros((Ax.shape[1], 3, 3), dtype=float)

    RDT[:, 0, 0] = Rxx
    RDT[:, 1, 1] = Ryy
    RDT[:, 2, 2] = Rzz

    RDT[:, 0, 1] = RDT[:, 1, 0] = Rxy
    RDT[:, 0, 2] = RDT[:, 2, 0] = Rxz
    RDT[:, 1, 2] = RDT[:, 2, 1] = Ryz
    # Eigenvalues in descending order
    eigenvalues = np.linalg.eigvalsh(RDT)[:, ::-1]
    eigenvalues = np.maximum(eigenvalues, 0.0)
    coverage = eigenvalues.sum(axis=1)
    isotropy = np.divide(3.0 * eigenvalues[:, 2],coverage,out=np.full(Ax.shape[1], np.nan),where=coverage > 0)
    return isotropy

"""function for creating spatial smoothing matrix based on triangulation neighbour
The input is the xyz coordinates of the node to be inverted (nx3 array). 
Each node will be paired based on triangulation, the node will have a value of 1, 
while the pair will have a value of -1, the rest will have a value of 0.
"""
def smooth_matrix(node_inv):
    def find_neighbors(pindex,triang):
        return triang.vertex_neighbor_vertices[1][
               triang.vertex_neighbor_vertices[0][pindex]:triang.vertex_neighbor_vertices[0][pindex + 1]]

    tri=Delaunay(node_inv)
    mat_list=[]
    for i in range(len(node_inv)):
        neighbor_indices=find_neighbors(i,tri)
        for j in range(len(neighbor_indices)):
            mat_j=np.zeros((len(node_inv)))
            mat_j[i]=1
            mat_j[neighbor_indices[j]]=-1
            mat_list.append(mat_j)

    return np.array(mat_list)

"""A class to determine whether or not to add a node in 
the middle of a tetrahedron with threshold consideration. 
If yes, a node will be added with the velocity value 
from the interpolation grid."""
class is_addnode:
    def __init__(self,hit_count,tres,node,deltn,interpP,interpS,nu_cpu=-1):
        self.hit_count=hit_count
        self.tres=tres
        self.node=node
        self.deltn=deltn
        self.interpP=interpP
        self.interpS=interpS
        self.nu_cpu=nu_cpu

    def cek_dis(self,p0,p1,p2,p3,p4):
        dis1 = np.sqrt(np.dot((p0 - p1), (p0 - p1)))
        dis2 = np.sqrt(np.dot((p0 - p2), (p0 - p2)))
        dis3 = np.sqrt(np.dot((p0 - p3), (p0 - p3)))
        dis4 = np.sqrt(np.dot((p0 - p4), (p0 - p4)))
        if dis1 >= 2*self.deltn and dis2 >= 2*self.deltn and dis3 >= 2*self.deltn and dis4 >= 2*self.deltn:
            dis = True
        else:
            dis = False
        return dis

    """add node if condition is met"""
    def cek_add(self,sim):
        p1=sim[0]
        p2=sim[1]
        p3=sim[2]
        p4=sim[3]
        cek_sum=self.hit_count[p1]+self.hit_count[p2]+self.hit_count[p3]+self.hit_count[p4]
        added_node=np.array([-99])
        add_velP=np.array([-99])
        add_velS=np.array([-99])
        if cek_sum>self.tres:
            added_node=(self.node[p1,:]+self.node[p2,:]+self.node[p3,:]+self.node[p4,:])/4
            check_added_node=self.cek_dis(added_node,self.node[p1,:],self.node[p2,:],self.node[p3,:],self.node[p4,:])
            if check_added_node==True:
                add_velP=self.interpP(np.array([added_node]))
                add_velS=self.interpS(np.array([added_node]))

        return added_node,add_velP[0],add_velS[0]

    """this is faster function than looping 1 by 1"""
    def add_simultanius(self,sim):
        cek_sum = (self.hit_count[sim[:, 0]] + self.hit_count[sim[:, 1]] + self.hit_count[sim[:, 2]] + self.hit_count[sim[:, 3]])
        add_sim = sim[cek_sum>self.tres]
        add_node = (self.node[add_sim[:, 0]] + self.node[add_sim[:, 1]] + self.node[add_sim[:, 2]] + self.node[add_sim[:, 3]])/4

        node_tree = KDTree(self.node)
        distance, index = node_tree.query(add_node, k=1, workers=self.nu_cpu)
        add_node=add_node[distance>=2*self.deltn]
        if len(add_node)!=0:
            add_velP=self.interpP(add_node)
            add_velS=self.interpS(add_node)
        else:
            add_velP=[]
            add_velS=[]
        return add_node,add_velP,add_velS




